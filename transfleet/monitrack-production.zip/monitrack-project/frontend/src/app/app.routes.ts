import { Routes } from '@angular/router';
import { authGuard, guestGuard, managerGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'login', canActivate: [guestGuard], loadComponent: () => import('./pages/login/login.component').then(m => m.LoginComponent) },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: 'dashboard',     loadComponent: () => import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'vehicles',      canActivate: [managerGuard], loadComponent: () => import('./pages/vehicles/vehicles.component').then(m => m.VehiclesComponent) },
      { path: 'drivers',       canActivate: [managerGuard], loadComponent: () => import('./pages/drivers/drivers.component').then(m => m.DriversComponent) },
      { path: 'trips',         loadComponent: () => import('./pages/trips/trips.component').then(m => m.TripsComponent) },
      { path: 'fuel',          canActivate: [managerGuard], loadComponent: () => import('./pages/fuel/fuel.component').then(m => m.FuelComponent) },
      { path: 'maintenance',   canActivate: [managerGuard], loadComponent: () => import('./pages/maintenance/maintenance.component').then(m => m.MaintenanceComponent) },
      { path: 'tracking',      canActivate: [managerGuard], loadComponent: () => import('./pages/tracking/tracking.component').then(m => m.TrackingComponent) },
      { path: 'notifications', loadComponent: () => import('./pages/notifications/notifications.component').then(m => m.NotificationsComponent) },
      { path: 'reports',       canActivate: [managerGuard], loadComponent: () => import('./pages/reports/reports.component').then(m => m.ReportsComponent) },
    ],
  },
  { path: '**', loadComponent: () => import('./pages/not-found/not-found.component').then(m => m.NotFoundComponent) },
];
