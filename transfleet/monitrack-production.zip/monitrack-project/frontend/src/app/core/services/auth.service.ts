import { Injectable, inject, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { User, LoginResponse } from '../models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http   = inject(HttpClient);
  private router = inject(Router);
  private api    = `${environment.apiUrl}/auth`;

  private _user = signal<User | null>(this.loadUser());
  readonly currentUser  = this._user.asReadonly();
  readonly isLoggedIn   = computed(() => !!this._user());
  readonly isManager    = computed(() => ['manager','admin'].includes(this._user()?.role ?? ''));
  readonly isDriver     = computed(() => this._user()?.role === 'driver');

  private loadUser(): User | null {
    try { return JSON.parse(localStorage.getItem('moni_user') || 'null'); } catch { return null; }
  }

  login(email: string, password: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.api}/login`, { email, password }).pipe(
      tap(res => {
        localStorage.setItem('moni_token', res.token);
        localStorage.setItem('moni_user',  JSON.stringify(res.user));
        this._user.set(res.user);
      })
    );
  }

  logout(): void {
    localStorage.removeItem('moni_token');
    localStorage.removeItem('moni_user');
    this._user.set(null);
    this.router.navigate(['/login']);
  }

  me(): Observable<User> {
    return this.http.get<User>(`${this.api}/me`).pipe(
      tap(u => { localStorage.setItem('moni_user', JSON.stringify(u)); this._user.set(u); })
    );
  }

  updateProfile(data: Partial<User>): Observable<any> {
    return this.http.put(`${this.api}/profile`, data).pipe(
      tap(() => { const u = { ...this._user()!, ...data }; localStorage.setItem('moni_user', JSON.stringify(u)); this._user.set(u); })
    );
  }

  changePassword(oldPassword: string, newPassword: string): Observable<any> {
    return this.http.put(`${this.api}/change-password`, { oldPassword, newPassword });
  }

  getToken(): string | null { return localStorage.getItem('moni_token'); }
}
