import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
<div class="login-page">
  <div class="login-card">
    <div class="login-header">
      <div class="logo">🚛</div>
      <h1>MONITRACK</h1>
      <p>Système de Gestion de Flotte<br><strong>TRANSIMEX S.A</strong></p>
    </div>

    <form (ngSubmit)="onSubmit()" class="login-form">
      @if (error()) {
        <div class="alert-error">{{ error() }}</div>
      }

      <div class="field">
        <label>Adresse e-mail</label>
        <input type="email" [(ngModel)]="email" name="email"
               placeholder="votre@email.cm" required autocomplete="username" />
      </div>

      <div class="field">
        <label>Mot de passe</label>
        <div class="input-pw">
          <input [type]="showPw() ? 'text' : 'password'" [(ngModel)]="password"
                 name="password" placeholder="••••••••" required autocomplete="current-password" />
          <button type="button" class="pw-toggle" (click)="showPw.update(v => !v)">
            {{ showPw() ? '🙈' : '👁️' }}
          </button>
        </div>
      </div>

      <button type="submit" class="btn-login" [disabled]="loading()">
        @if (loading()) { <span class="spinner"></span> Connexion… }
        @else { Se connecter }
      </button>
    </form>

    <div class="demo-accounts">
      <p>Comptes de démonstration :</p>
      <button type="button" class="demo-btn" (click)="fillDemo('manager')">👔 Gestionnaire</button>
      <button type="button" class="demo-btn" (click)="fillDemo('driver')">🚗 Conducteur</button>
    </div>
  </div>
</div>
  `,
  styles: [`
.login-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}
.login-card {
  background: #fff;
  border-radius: 16px;
  padding: 40px;
  width: 100%;
  max-width: 420px;
  box-shadow: 0 20px 60px rgba(0,0,0,.3);
}
.login-header {
  text-align: center;
  margin-bottom: 32px;
  .logo { font-size: 3rem; margin-bottom: 8px; }
  h1 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin: 0; letter-spacing: 2px; }
  p { color: #64748b; margin: 8px 0 0; font-size: .9rem; line-height: 1.5; }
}
.login-form { display: flex; flex-direction: column; gap: 18px; }
.alert-error {
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #dc2626;
  padding: 10px 14px;
  border-radius: 8px;
  font-size: .875rem;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  label { font-size: .85rem; font-weight: 600; color: #374151; }
  input {
    width: 100%;
    padding: 11px 14px;
    border: 1.5px solid #e2e8f0;
    border-radius: 8px;
    font-size: .95rem;
    outline: none;
    transition: border-color .2s;
    box-sizing: border-box;
    &:focus { border-color: #38bdf8; }
  }
}
.input-pw {
  position: relative;
  input { padding-right: 44px; width: 100%; box-sizing: border-box; }
}
.pw-toggle {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  border: none;
  background: transparent;
  cursor: pointer;
  font-size: 1rem;
}
.btn-login {
  padding: 13px;
  background: linear-gradient(135deg, #0284c7, #38bdf8);
  color: #fff;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: opacity .2s;
  &:disabled { opacity: .7; cursor: not-allowed; }
  &:hover:not(:disabled) { opacity: .9; }
}
.spinner {
  width: 16px; height: 16px;
  border: 2px solid rgba(255,255,255,.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin .6s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.demo-accounts {
  margin-top: 24px;
  text-align: center;
  p { font-size: .8rem; color: #94a3b8; margin-bottom: 10px; }
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.demo-btn {
  padding: 8px 16px;
  border: 1.5px solid #e2e8f0;
  border-radius: 8px;
  background: #f8fafc;
  cursor: pointer;
  font-size: .85rem;
  color: #475569;
  transition: background .15s;
  &:hover { background: #e2e8f0; }
}
  `],
})
export class LoginComponent {
  private auth   = inject(AuthService);
  private router = inject(Router);

  email    = '';
  password = '';
  loading  = signal(false);
  error    = signal('');
  showPw   = signal(false);

  fillDemo(role: 'manager' | 'driver'): void {
    this.email    = role === 'manager' ? 'manager@transimex.cm' : 'jbnkomo@transimex.cm';
    this.password = 'password123';
    this.error.set('');
  }

  onSubmit(): void {
    if (!this.email || !this.password) {
      this.error.set('Veuillez renseigner tous les champs.');
      return;
    }
    this.loading.set(true);
    this.error.set('');

    this.auth.login(this.email.trim(), this.password).subscribe({
      next: () => this.router.navigate(['/dashboard']),
      error: (err) => {
        this.error.set(err?.error?.message || 'Identifiants incorrects. Réessayez.');
        this.loading.set(false);
      },
    });
  }
}
