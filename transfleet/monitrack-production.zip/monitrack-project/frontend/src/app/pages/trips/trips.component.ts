import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { AuthService } from '../../core/services/auth.service';
import { Trip, Vehicle, Driver } from '../../core/models';

@Component({
  selector: 'app-trips', standalone: true, imports: [CommonModule, FormsModule, DatePipe],
  template: `
<div class="page">
  <div class="page-header">
    <div><h1>🗺️ Trajets</h1><p class="subtitle">Planification et suivi des missions</p></div>
    @if (isManager()) { <button class="btn btn-primary" (click)="openModal()">+ Nouveau trajet</button> }
  </div>
  <div class="filters">
    <select [(ngModel)]="filterStatus" (change)="load()" class="filter-select">
      <option value="">Tous les statuts</option>
      <option value="planned">Planifié</option><option value="in_progress">En cours</option>
      <option value="completed">Terminé</option><option value="cancelled">Annulé</option>
    </select>
  </div>
  @if (loading()) { <div class="loading-state">Chargement…</div> }
  @if (!loading()) {
    <div class="table-card">
      <table>
        <thead><tr><th>Départ</th><th>Arrivée</th><th>Véhicule</th><th>Conducteur</th><th>Date</th><th>Distance</th><th>Statut</th><th>Actions</th></tr></thead>
        <tbody>
          @for (t of trips(); track t.id) {
            <tr>
              <td>{{ t.from_location }}</td>
              <td>{{ t.to_location }}</td>
              <td>{{ t.vehicle?.plate }} – {{ t.vehicle?.brand }} {{ t.vehicle?.model }}</td>
              <td>{{ t.driver?.user?.first_name }} {{ t.driver?.user?.last_name }}</td>
              <td>{{ (t.actual_start || t.scheduled_start) | date:"dd/MM/yy HH:mm" }}</td>
              <td>{{ t.actual_distance ?? t.estimated_distance ?? "—" }} km</td>
              <td><span class="badge" [class]="'badge-' + t.status">{{ statusLabel(t.status) }}</span></td>
              <td class="actions">
                @if (isManager() && t.status === "planned") {
                  <button class="btn-icon-sm success" title="Démarrer" (click)="startTrip(t)">▶️</button>
                }
                @if (isManager() && t.status === "in_progress") {
                  <button class="btn-icon-sm success" title="Terminer" (click)="openComplete(t)">✅</button>
                  <button class="btn-icon-sm danger" title="Annuler" (click)="cancelTrip(t)">❌</button>
                }
              </td>
            </tr>
          } @empty {
            <tr><td colspan="8" class="empty">Aucun trajet trouvé.</td></tr>
          }
        </tbody>
      </table>
      <div class="table-footer">Total : {{ total() }} trajet(s)</div>
    </div>
  }

  <!-- Modal nouveau trajet -->
  @if (showModal()) {
    <div class="modal-backdrop" (click)="closeModal()">
      <div class="modal" (click)="$event.stopPropagation()">
        <div class="modal-header"><h2>Nouveau trajet</h2><button class="modal-close" (click)="closeModal()">✕</button></div>
        <div class="modal-body">
          @if (formError()) { <div class="alert-error">{{ formError() }}</div> }
          <div class="form-grid">
            <div class="field"><label>Véhicule disponible *</label>
              <select [(ngModel)]="form.vehicle_id">
                <option value="">-- Sélectionner --</option>
                @for (v of availVehicles(); track v.id) { <option [value]="v.id">{{ v.plate }} – {{ v.brand }} {{ v.model }}</option> }
              </select>
            </div>
            <div class="field"><label>Conducteur disponible *</label>
              <select [(ngModel)]="form.driver_id">
                <option value="">-- Sélectionner --</option>
                @for (d of availDrivers(); track d.id) { <option [value]="d.id">{{ d.user?.first_name }} {{ d.user?.last_name }}</option> }
              </select>
            </div>
            <div class="field"><label>Départ *</label><input [(ngModel)]="form.from_location" placeholder="Lieu de départ" /></div>
            <div class="field"><label>Destination *</label><input [(ngModel)]="form.to_location" placeholder="Lieu d'arrivée" /></div>
            <div class="field"><label>Distance estimée (km)</label><input type="number" [(ngModel)]="form.estimated_distance" /></div>
            <div class="field"><label>Durée estimée</label><input [(ngModel)]="form.estimated_duration" placeholder="4h30" /></div>
            <div class="field"><label>Objet du trajet</label><input [(ngModel)]="form.purpose" placeholder="Livraison, Inspection…" /></div>
            <div class="field"><label>Passagers</label><input type="number" [(ngModel)]="form.passengers" min="0" /></div>
            <div class="field"><label>Date/heure de départ prévue</label><input type="datetime-local" [(ngModel)]="form.scheduled_start" /></div>
            <div class="field"><label>Notes</label><textarea [(ngModel)]="form.notes" rows="2"></textarea></div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" (click)="closeModal()">Annuler</button>
          <button class="btn btn-primary" (click)="save()" [disabled]="saving()">{{ saving() ? "Enregistrement…" : "Planifier" }}</button>
        </div>
      </div>
    </div>
  }

  <!-- Modal terminer trajet -->
  @if (showComplete()) {
    <div class="modal-backdrop" (click)="showComplete.set(false)">
      <div class="modal modal-sm" (click)="$event.stopPropagation()">
        <div class="modal-header"><h2>Terminer le trajet</h2><button class="modal-close" (click)="showComplete.set(false)">✕</button></div>
        <div class="modal-body">
          <div class="form-grid">
            <div class="field"><label>Distance réelle (km)</label><input type="number" [(ngModel)]="completeForm.actual_distance" /></div>
            <div class="field"><label>Durée réelle</label><input [(ngModel)]="completeForm.actual_duration" placeholder="4h08" /></div>
            <div class="field"><label>Carburant consommé (L)</label><input type="number" [(ngModel)]="completeForm.fuel_used" /></div>
            <div class="field"><label>Notes</label><textarea [(ngModel)]="completeForm.notes" rows="2"></textarea></div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" (click)="showComplete.set(false)">Annuler</button>
          <button class="btn btn-success" (click)="completeTrip()" [disabled]="saving()">{{ saving() ? "…" : "Terminer le trajet" }}</button>
        </div>
      </div>
    </div>
  }
</div>`,
  styleUrl: './trips.component.scss',
})
export class TripsComponent implements OnInit {
  private api  = inject(ApiService);
  auth = inject(AuthService);
  isManager = this.auth.isManager;

  trips = signal<Trip[]>([]); total = signal(0);
  loading = signal(false); showModal = signal(false); showComplete = signal(false); saving = signal(false);
  formError = signal(''); selectedTrip = signal<Trip | null>(null);
  availVehicles = signal<Vehicle[]>([]); availDrivers = signal<Driver[]>([]);
  filterStatus = '';
  form: Record<string,any> = this.emptyForm();
  completeForm: Record<string,any> = { actual_distance: null, actual_duration: '', fuel_used: null, notes: '' };

  ngOnInit() { this.load(); }
  load(): void {
    this.loading.set(true);
    const q: Record<string,any> = { limit: 100 };
    if (this.filterStatus) q['status'] = this.filterStatus;
    this.api.getTrips(q).subscribe({ next: r => { this.trips.set(r.data); this.total.set(r.total); this.loading.set(false); }, error: () => this.loading.set(false) });
  }
  openModal(): void {
    this.form = this.emptyForm(); this.formError.set(''); this.showModal.set(true);
    this.api.getVehicles({ status:'available', limit:100 }).subscribe(r => this.availVehicles.set(r.data));
    this.api.getDrivers({ status:'available', limit:100 }).subscribe(r => this.availDrivers.set(r.data));
  }
  closeModal(): void { this.showModal.set(false); }
  save(): void {
    if (!this.form['vehicle_id'] || !this.form['driver_id'] || !this.form['from_location'] || !this.form['to_location']) { this.formError.set('Champs obligatoires manquants.'); return; }
    this.saving.set(true);
    this.api.createTrip(this.form).subscribe({ next: () => { this.closeModal(); this.load(); this.saving.set(false); }, error: (e:any) => { this.formError.set(e?.error?.message || 'Erreur'); this.saving.set(false); } });
  }
  startTrip(t: Trip): void {
    if (confirm(`Démarrer le trajet ${t.from_location} → ${t.to_location} ?`)) {
      this.api.startTrip(t.id).subscribe({ next: () => this.load(), error: (e:any) => alert(e?.error?.message || 'Erreur') });
    }
  }
  openComplete(t: Trip): void { this.selectedTrip.set(t); this.completeForm = { actual_distance: t.estimated_distance, actual_duration: t.estimated_duration, fuel_used: null, notes: '' }; this.showComplete.set(true); }
  completeTrip(): void {
    this.saving.set(true);
    this.api.completeTrip(this.selectedTrip()!.id, this.completeForm).subscribe({ next: () => { this.showComplete.set(false); this.load(); this.saving.set(false); }, error: (e:any) => { alert(e?.error?.message || 'Erreur'); this.saving.set(false); } });
  }
  cancelTrip(t: Trip): void {
    const reason = prompt("Raison de l'annulation (optionnel) :");
    if (reason !== null) this.api.cancelTrip(t.id, reason || undefined).subscribe({ next: () => this.load(), error: (e:any) => alert(e?.error?.message || 'Erreur') });
  }
  emptyForm() { return { vehicle_id:'', driver_id:'', from_location:'', to_location:'', estimated_distance: null, estimated_duration:'', purpose:'', passengers:0, scheduled_start:'', notes:'' }; }
  statusLabel(s: string): string { return ({planned:'Planifié',in_progress:'En cours',completed:'Terminé',cancelled:'Annulé'})[s as keyof object] ?? s; }
}
