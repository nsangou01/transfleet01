import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { ApiService } from "../../core/services/api.service";
import { FuelRecord, Vehicle, Driver } from "../../core/models";

@Component({
  selector: "app-fuel", standalone: true, imports: [CommonModule, FormsModule],
  template: `
<div class="page">
  <div class="page-header">
    <div><h1>⛽ Carburant</h1><p class="subtitle">Suivi de la consommation</p></div>
    <button class="btn btn-primary" (click)="openModal()">+ Saisir ravitaillement</button>
  </div>
  <div class="kpi-row">
    <div class="kpi-sm"><span>Total mois</span><strong>{{ totalCost().toLocaleString() }} FCFA</strong></div>
    <div class="kpi-sm"><span>Volume total</span><strong>{{ totalQty() }} L</strong></div>
    <div class="kpi-sm"><span>Nombre d'opérations</span><strong>{{ total() }}</strong></div>
  </div>
  @if (loading()) { <div class="loading-state">Chargement…</div> }
  @if (!loading()) {
    <div class="table-card">
      <table>
        <thead><tr><th>Date</th><th>Véhicule</th><th>Conducteur</th><th>Station</th><th>Qté (L)</th><th>Prix/L</th><th>Total FCFA</th><th>Actions</th></tr></thead>
        <tbody>
          @for (f of records(); track f.id) {
            <tr>
              <td>{{ f.date }}</td>
              <td>{{ f.vehicle?.plate }} – {{ f.vehicle?.brand }}</td>
              <td>{{ f.driver?.user?.first_name }} {{ f.driver?.user?.last_name }}</td>
              <td>{{ f.station_name ?? "—" }}, {{ f.station_city ?? "" }}</td>
              <td>{{ f.quantity }}</td>
              <td>{{ f.price_per_litre.toLocaleString() }}</td>
              <td><strong>{{ f.total_cost.toLocaleString() }}</strong></td>
              <td class="actions">
                <button class="btn-icon-sm" (click)="openModal(f)">✏️</button>
                <button class="btn-icon-sm danger" (click)="del(f)">🗑️</button>
              </td>
            </tr>
          } @empty { <tr><td colspan="8" class="empty">Aucun enregistrement.</td></tr> }
        </tbody>
      </table>
      <div class="table-footer">{{ total() }} enregistrement(s)</div>
    </div>
  }
  @if (showModal()) {
    <div class="modal-backdrop" (click)="closeModal()">
      <div class="modal" (click)="$event.stopPropagation()">
        <div class="modal-header"><h2>{{ editing() ? "Modifier" : "Nouveau ravitaillement" }}</h2><button class="modal-close" (click)="closeModal()">✕</button></div>
        <div class="modal-body">
          @if (formError()) { <div class="alert-error">{{ formError() }}</div> }
          <div class="form-grid">
            <div class="field"><label>Véhicule *</label>
              <select [(ngModel)]="form.vehicle_id">
                <option value="">-- Sélectionner --</option>
                @for (v of vehicles(); track v.id) { <option [value]="v.id">{{ v.plate }} – {{ v.brand }}</option> }
              </select>
            </div>
            <div class="field"><label>Conducteur *</label>
              <select [(ngModel)]="form.driver_id">
                <option value="">-- Sélectionner --</option>
                @for (d of drivers(); track d.id) { <option [value]="d.id">{{ d.user?.first_name }} {{ d.user?.last_name }}</option> }
              </select>
            </div>
            <div class="field"><label>Date *</label><input type="date" [(ngModel)]="form.date" /></div>
            <div class="field"><label>Type carburant</label>
              <select [(ngModel)]="form.fuel_type">
                <option value="diesel">Diesel</option><option value="gasoline">Essence</option>
                <option value="hybrid">Hybride</option><option value="electric">Électrique</option>
              </select>
            </div>
            <div class="field"><label>Quantité (L) *</label><input type="number" [(ngModel)]="form.quantity" (input)="calcTotal()" /></div>
            <div class="field"><label>Prix/Litre (FCFA) *</label><input type="number" [(ngModel)]="form.price_per_litre" (input)="calcTotal()" /></div>
            <div class="field"><label>Total FCFA</label><input type="number" [(ngModel)]="form.total_cost" readonly /></div>
            <div class="field"><label>Station</label><input [(ngModel)]="form.station_name" placeholder="Total, Tradex…" /></div>
            <div class="field"><label>Ville</label><input [(ngModel)]="form.station_city" placeholder="Douala, Yaoundé…" /></div>
            <div class="field"><label>Kilométrage au ravitaillement</label><input type="number" [(ngModel)]="form.mileage_at_fill" /></div>
            <div class="field"><label>Notes</label><textarea [(ngModel)]="form.notes" rows="2"></textarea></div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" (click)="closeModal()">Annuler</button>
          <button class="btn btn-primary" (click)="save()" [disabled]="saving()">{{ saving() ? "…" : (editing() ? "Modifier" : "Enregistrer") }}</button>
        </div>
      </div>
    </div>
  }
</div>`,
  styleUrl: "./fuel.component.scss",
})
export class FuelComponent implements OnInit {
  private api = inject(ApiService);
  records = signal<FuelRecord[]>([]); total = signal(0);
  vehicles = signal<Vehicle[]>([]); drivers = signal<Driver[]>([]);
  loading = signal(false); showModal = signal(false); saving = signal(false);
  formError = signal(""); editing = signal<FuelRecord | null>(null);
  form: Record<string,any> = this.emptyForm();
  totalCost = signal(0); totalQty = signal(0);

  ngOnInit() { this.load(); }
  load(): void {
    this.loading.set(true);
    this.api.getFuel({ limit: 100 }).subscribe({ next: r => {
      this.records.set(r.data); this.total.set(r.total);
      this.totalCost.set(r.data.reduce((s: number, f: FuelRecord) => s + +f.total_cost, 0));
      this.totalQty.set(Math.round(r.data.reduce((s: number, f: FuelRecord) => s + +f.quantity, 0)));
      this.loading.set(false);
    }, error: () => this.loading.set(false) });
  }
  openModal(f?: FuelRecord): void {
    this.editing.set(f ?? null);
    this.form = f ? { ...f } : this.emptyForm();
    this.formError.set(""); this.showModal.set(true);
    this.api.getVehicles({ limit:100 }).subscribe(r => this.vehicles.set(r.data));
    this.api.getDrivers({ limit:100 }).subscribe(r => this.drivers.set(r.data));
  }
  closeModal(): void { this.showModal.set(false); this.editing.set(null); }
  calcTotal(): void { if (this.form["quantity"] && this.form["price_per_litre"]) this.form["total_cost"] = Math.round(+this.form["quantity"] * +this.form["price_per_litre"]); }
  save(): void {
    if (!this.form["vehicle_id"] || !this.form["driver_id"] || !this.form["quantity"] || !this.form["price_per_litre"] || !this.form["date"]) { this.formError.set("Champs obligatoires manquants."); return; }
    this.saving.set(true);
    const obs = this.editing() ? this.api.updateFuel(this.editing()!.id, this.form) : this.api.createFuel(this.form);
    obs.subscribe({ next: () => { this.closeModal(); this.load(); this.saving.set(false); }, error: (e:any) => { this.formError.set(e?.error?.message || "Erreur"); this.saving.set(false); } });
  }
  del(f: FuelRecord): void {
    if (confirm("Supprimer cet enregistrement ?")) this.api.deleteFuel(f.id).subscribe({ next: () => this.load(), error: (e:any) => alert(e?.error?.message || "Erreur") });
  }
  emptyForm() { return { vehicle_id:"", driver_id:"", date: new Date().toISOString().split("T")[0], quantity: null, price_per_litre: 750, total_cost: null, fuel_type:"diesel", station_name:"", station_city:"", mileage_at_fill: null, notes:"" }; }
}
