import { Component } from "@angular/core";
import { RouterLink } from "@angular/router";

@Component({
  selector: "app-not-found", standalone: true, imports: [RouterLink],
  template: `
<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:#f8fafc;text-align:center;padding:20px;">
  <div>
    <div style="font-size:5rem;margin-bottom:16px;">🚛</div>
    <h1 style="font-size:4rem;font-weight:800;color:#0f172a;margin:0;">404</h1>
    <p style="color:#64748b;font-size:1.1rem;margin:16px 0 32px;">Cette page n'existe pas ou a été déplacée.</p>
    <a routerLink="/dashboard" style="display:inline-block;padding:12px 24px;background:linear-gradient(135deg,#0284c7,#38bdf8);color:#fff;border-radius:8px;text-decoration:none;font-weight:600;">Retour au tableau de bord</a>
  </div>
</div>`,
})
export class NotFoundComponent {}
