import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { AuthService } from '../../core/services/auth.service';

interface AppNotification {
  id: number; sender_id?: number; recipient_id?: number;
  type: 'alert' | 'info' | 'success' | 'warning';
  title: string; message: string; is_read: boolean;
  read_at?: string; target_role?: string; created_at?: string;
}

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  template: `
<div class="page">
  <div class="page-header">
    <div><h1>🔔 Notifications</h1><p class="subtitle">{{ unread() }} non lue(s)</p></div>
    <div class="header-actions">
      <button class="btn btn-secondary" (click)="markAll()" [disabled]="unread() === 0">Tout marquer lu</button>
      @if (isManager()) { <button class="btn btn-primary" (click)="showModal.set(true)">+ Envoyer</button> }
    </div>
  </div>
  <div class="filters">
    <select [(ngModel)]="filterRead" (change)="load()" class="filter-select">
      <option value="">Toutes</option>
      <option value="false">Non lues</option>
      <option value="true">Lues</option>
    </select>
  </div>
  @if (loading()) { <div class="loading-state">Chargement…</div> }
  <div class="notif-list">
    @for (n of notifs(); track n.id) {
      <div class="notif-item" [class.unread]="!n.is_read" [ngClass]="'notif-' + n.type">
        <div class="notif-icon">{{ iconMap[n.type] }}</div>
        <div class="notif-body">
          <div class="notif-title">{{ n.title }}</div>
          <div class="notif-message">{{ n.message }}</div>
          <div class="notif-meta">{{ n.created_at | date:'dd/MM/yyyy HH:mm' }}</div>
        </div>
        <div class="notif-actions">
          @if (!n.is_read) {
            <button class="btn-icon-sm success" title="Marquer lu" (click)="markOne(n)">✓</button>
          }
          @if (isManager()) {
            <button class="btn-icon-sm danger" title="Supprimer" (click)="del(n)">🗑️</button>
          }
        </div>
      </div>
    } @empty {
      <div class="empty-state">Aucune notification.</div>
    }
  </div>

  @if (showModal()) {
    <div class="modal-backdrop" (click)="showModal.set(false)">
      <div class="modal modal-sm" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2>Envoyer une notification</h2>
          <button class="modal-close" (click)="showModal.set(false)">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-grid">
            <div class="field">
              <label>Type</label>
              <select [(ngModel)]="form['type']">
                <option value="info">Information</option>
                <option value="success">Succès</option>
                <option value="warning">Avertissement</option>
                <option value="alert">Alerte</option>
              </select>
            </div>
            <div class="field">
              <label>Destinataires</label>
              <select [(ngModel)]="form['target_role']">
                <option value="all">Tous</option>
                <option value="manager">Gestionnaires</option>
                <option value="driver">Conducteurs</option>
              </select>
            </div>
            <div class="field">
              <label>Titre *</label>
              <input [(ngModel)]="form['title']" />
            </div>
            <div class="field">
              <label>Message *</label>
              <textarea [(ngModel)]="form['message']" rows="4"></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" (click)="showModal.set(false)">Annuler</button>
          <button class="btn btn-primary" (click)="send()" [disabled]="sending()">
            {{ sending() ? 'Envoi…' : 'Envoyer' }}
          </button>
        </div>
      </div>
    </div>
  }
</div>
  `,
  styleUrl: './notifications.component.scss',
})
export class NotificationsComponent implements OnInit {
  private api = inject(ApiService);
  auth        = inject(AuthService);
  isManager   = this.auth.isManager;

  notifs   = signal<AppNotification[]>([]);
  total    = signal(0);
  unread   = signal(0);
  loading  = signal(false);
  showModal= signal(false);
  sending  = signal(false);
  filterRead = '';
  form: Record<string, any> = { type: 'info', target_role: 'all', title: '', message: '' };
  iconMap: Record<string, string> = { alert: '🔴', info: '🔵', success: '🟢', warning: '🟡' };

  ngOnInit() { this.load(); }

  load(): void {
    this.loading.set(true);
    const q: Record<string, any> = { limit: 100 };
    if (this.filterRead !== '') q['is_read'] = this.filterRead;
    this.api.getNotifications(q).subscribe({
      next: (r: any) => { this.notifs.set(r.data); this.total.set(r.total); this.unread.set(r.unread ?? 0); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  markOne(n: AppNotification): void { this.api.markRead(n.id).subscribe(() => this.load()); }
  markAll(): void { this.api.markAllRead().subscribe(() => this.load()); }
  del(n: AppNotification): void {
    if (confirm('Supprimer cette notification ?')) this.api.deleteNotification(n.id).subscribe(() => this.load());
  }
  send(): void {
    if (!this.form['title'] || !this.form['message']) return;
    this.sending.set(true);
    this.api.createNotification(this.form).subscribe({
      next: () => { this.showModal.set(false); this.form = { type: 'info', target_role: 'all', title: '', message: '' }; this.load(); this.sending.set(false); },
      error: () => this.sending.set(false),
    });
  }
}
