import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/services/api.service';
import { DashboardStats, Maintenance } from '../../core/models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
<div class="page">
  <div class="page-header">
    <div>
      <h1>Tableau de bord</h1>
      <p class="subtitle">Vue d'ensemble de la flotte TRANSIMEX</p>
    </div>
    <button class="btn btn-secondary" (click)="load()">↻ Actualiser</button>
  </div>

  @if (loading()) {
    <div class="loading-state">Chargement…</div>
  }

  @if (stats(); as s) {
    <!-- KPI Cards -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-icon vehicles">🚗</div>
        <div class="kpi-body">
          <div class="kpi-value">{{ s.vehicles.total }}</div>
          <div class="kpi-label">Véhicules totaux</div>
          <div class="kpi-detail">
            <span class="chip green">{{ s.vehicles.available ?? 0 }} dispos</span>
            <span class="chip blue">{{ s.vehicles.in_use ?? 0 }} en route</span>
            <span class="chip orange">{{ s.vehicles.maintenance ?? 0 }} maint.</span>
          </div>
        </div>
      </div>

      <div class="kpi-card">
        <div class="kpi-icon drivers">👤</div>
        <div class="kpi-body">
          <div class="kpi-value">{{ s.drivers.total }}</div>
          <div class="kpi-label">Conducteurs</div>
          <div class="kpi-detail">
            <span class="chip green">{{ s.drivers.available ?? 0 }} dispos</span>
            <span class="chip blue">{{ s.drivers.on_trip ?? 0 }} en mission</span>
          </div>
        </div>
      </div>

      <div class="kpi-card">
        <div class="kpi-icon trips">🗺️</div>
        <div class="kpi-body">
          <div class="kpi-value">{{ s.trips.total }}</div>
          <div class="kpi-label">Trajets totaux</div>
          <div class="kpi-detail">
            <span class="chip blue">{{ s.trips.in_progress ?? 0 }} en cours</span>
            <span class="chip green">{{ s.trips.completed ?? 0 }} terminés</span>
          </div>
        </div>
      </div>

      <div class="kpi-card">
        <div class="kpi-icon fuel">⛽</div>
        <div class="kpi-body">
          <div class="kpi-value">{{ (s.fuel.monthCost / 1000).toFixed(0) }}K</div>
          <div class="kpi-label">Coût carburant (FCFA)</div>
          <div class="kpi-detail">
            <span class="chip orange">Aujourd'hui : {{ s.fuel.todayCost.toLocaleString() }} F</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Maintenance alerts -->
    @if (s.maintenance.pending > 0) {
      <div class="section">
        <div class="section-header">
          <h2>⚠️ Maintenances en attente ({{ s.maintenance.pending }})</h2>
          <a routerLink="/maintenance" class="link">Voir tout →</a>
        </div>
        <div class="alert-list">
          @for (m of s.maintenance.records; track m.id) {
            <div class="alert-item" [class.urgent]="m.status === 'in_progress'">
              <div class="alert-icon">🔧</div>
              <div class="alert-body">
                <strong>{{ m.description }}</strong>
                <span>Prévu le {{ m.scheduled_date | date:'dd/MM/yyyy' }}</span>
              </div>
              <span class="badge" [class]="'badge-' + m.status">{{ statusLabel(m.status) }}</span>
            </div>
          }
        </div>
      </div>
    }

    <!-- Quick actions -->
    <div class="section">
      <h2>Actions rapides</h2>
      <div class="quick-actions">
        <a routerLink="/trips" class="action-card">
          <span class="action-icon">➕</span>
          <span>Nouveau trajet</span>
        </a>
        <a routerLink="/vehicles" class="action-card">
          <span class="action-icon">🚗</span>
          <span>Gérer les véhicules</span>
        </a>
        <a routerLink="/fuel" class="action-card">
          <span class="action-icon">⛽</span>
          <span>Saisir carburant</span>
        </a>
        <a routerLink="/notifications" class="action-card">
          <span class="action-icon">🔔</span>
          <span>Notifications</span>
        </a>
      </div>
    </div>
  }

  @if (error()) {
    <div class="error-state">
      ⚠️ {{ error() }}
      <button class="btn btn-secondary" (click)="load()">Réessayer</button>
    </div>
  }
</div>
  `,
  styles: [`
.page { max-width: 1200px; }
.page-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:28px; }
.page-header h1 { margin:0; font-size:1.6rem; font-weight:700; color:#0f172a; }
.subtitle { color:#64748b; margin:4px 0 0; }

.kpi-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:20px; margin-bottom:32px; }
.kpi-card {
  background:#fff;
  border-radius:12px;
  padding:20px;
  display:flex;
  gap:16px;
  box-shadow:0 1px 3px rgba(0,0,0,.06);
  border:1px solid #f1f5f9;
}
.kpi-icon { width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0;
  &.vehicles{background:#eff6ff;} &.drivers{background:#f0fdf4;} &.trips{background:#faf5ff;} &.fuel{background:#fff7ed;}
}
.kpi-value { font-size:2rem;font-weight:800;color:#0f172a;line-height:1; }
.kpi-label { font-size:.8rem;color:#64748b;margin:4px 0 8px; }
.kpi-detail { display:flex;flex-wrap:wrap;gap:6px; }

.chip { font-size:.7rem;padding:2px 8px;border-radius:99px;font-weight:600;
  &.green{background:#dcfce7;color:#15803d;}
  &.blue{background:#dbeafe;color:#1d4ed8;}
  &.orange{background:#ffedd5;color:#c2410c;}
}

.section { margin-bottom:28px; }
.section-header { display:flex;justify-content:space-between;align-items:center;margin-bottom:12px; }
.section-header h2 { margin:0;font-size:1rem;font-weight:700;color:#1e293b; }
.link { font-size:.85rem;color:#0284c7;text-decoration:none; &:hover{text-decoration:underline;} }

.alert-list { display:flex;flex-direction:column;gap:8px; }
.alert-item {
  background:#fff;
  border:1px solid #e2e8f0;
  border-radius:10px;
  padding:14px 16px;
  display:flex;
  align-items:center;
  gap:12px;
  &.urgent { border-left:3px solid #ef4444;background:#fff5f5; }
}
.alert-icon { font-size:1.2rem; }
.alert-body { flex:1; strong{display:block;font-size:.9rem;color:#1e293b;} span{font-size:.8rem;color:#64748b;} }

.badge { padding:3px 10px;border-radius:99px;font-size:.75rem;font-weight:600;
  &.badge-scheduled{background:#fef9c3;color:#854d0e;}
  &.badge-in_progress{background:#dbeafe;color:#1d4ed8;}
  &.badge-completed{background:#dcfce7;color:#15803d;}
  &.badge-cancelled{background:#fee2e2;color:#dc2626;}
}

.quick-actions { display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px; }
.action-card {
  background:#fff;
  border:1px solid #e2e8f0;
  border-radius:10px;
  padding:20px 16px;
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:8px;
  text-decoration:none;
  color:#374151;
  font-size:.875rem;
  font-weight:500;
  transition:all .15s;
  cursor:pointer;
  &:hover{background:#f0f9ff;border-color:#38bdf8;color:#0284c7;}
}
.action-icon { font-size:1.5rem; }

.loading-state { text-align:center;padding:40px;color:#64748b; }
.error-state { background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:20px;color:#dc2626;display:flex;align-items:center;gap:16px;margin-top:20px; }

.btn { padding:9px 18px;border-radius:8px;border:none;cursor:pointer;font-size:.875rem;font-weight:600;transition:.15s; }
.btn-secondary { background:#f1f5f9;color:#374151;&:hover{background:#e2e8f0;} }
  `],
})
export class DashboardComponent implements OnInit {
  private api = inject(ApiService);
  stats   = signal<DashboardStats | null>(null);
  loading = signal(false);
  error   = signal('');

  ngOnInit() { this.load(); }

  load(): void {
    this.loading.set(true);
    this.error.set('');
    this.api.getDashboard().subscribe({
      next: (d) => { this.stats.set(d); this.loading.set(false); },
      error: (e) => { this.error.set(e?.error?.message || 'Erreur de chargement'); this.loading.set(false); },
    });
  }

  statusLabel(s: string): string {
    const map: Record<string, string> = { scheduled:'Planifiée', in_progress:'En cours', completed:'Terminée', cancelled:'Annulée' };
    return map[s] ?? s;
  }
}
