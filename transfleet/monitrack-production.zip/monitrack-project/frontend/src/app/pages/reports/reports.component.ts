import { Component, inject, signal, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { ApiService } from "../../core/services/api.service";

@Component({
  selector: "app-reports", standalone: true, imports: [CommonModule, FormsModule],
  template: `
<div class="page">
  <div class="page-header">
    <div><h1>📈 Rapports</h1><p class="subtitle">Analyse de la flotte et des coûts</p></div>
    <button class="btn btn-secondary" (click)="exportCsv()">⬇️ Exporter CSV</button>
  </div>
  <div class="report-filters">
    <div class="field"><label>Du</label><input type="date" [(ngModel)]="start" /></div>
    <div class="field"><label>Au</label><input type="date" [(ngModel)]="end" /></div>
    <button class="btn btn-primary" (click)="load()">Générer le rapport</button>
  </div>
  @if (loading()) { <div class="loading-state">Génération du rapport…</div> }
  @if (report()) {
    <div class="report-summary">
      <div class="kpi-sm"><span>Coût total carburant</span><strong>{{ report()!.totalCost.toLocaleString() }} FCFA</strong></div>
      <div class="kpi-sm"><span>Volume total</span><strong>{{ report()!.totalQuantity }} L</strong></div>
      <div class="kpi-sm"><span>Opérations</span><strong>{{ report()!.records.length }}</strong></div>
    </div>
    <div class="section">
      <h2>Détail par véhicule</h2>
      <div class="table-card">
        <table>
          <thead><tr><th>Véhicule</th><th>Opérations</th><th>Volume (L)</th><th>Coût (FCFA)</th><th>% du total</th></tr></thead>
          <tbody>
            @for (v of report()!.byVehicle; track v.vehicle?.id) {
              <tr>
                <td>{{ v.vehicle?.plate }} – {{ v.vehicle?.brand }}</td>
                <td>{{ v.count }}</td>
                <td>{{ v.qty.toFixed(1) }}</td>
                <td><strong>{{ v.cost.toLocaleString() }}</strong></td>
                <td>
                  <div class="progress-bar">
                    <div class="progress-fill" [style.width.%]="report()!.totalCost ? v.cost / report()!.totalCost * 100 : 0"></div>
                  </div>
                  {{ report()!.totalCost ? (v.cost / report()!.totalCost * 100).toFixed(1) : 0 }}%
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  }
</div>`,
  styles: [`
.report-filters{display:flex;gap:16px;align-items:flex-end;margin-bottom:24px;flex-wrap:wrap;padding:16px;background:#fff;border-radius:10px;border:1px solid #e2e8f0;}
.report-filters .field{display:flex;flex-direction:column;gap:4px;label{font-size:.8rem;font-weight:600;color:#374151;}input{padding:8px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.9rem;}}
.report-summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:24px;}
.kpi-sm{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:16px;display:flex;flex-direction:column;gap:4px;span{font-size:.8rem;color:#64748b;}strong{font-size:1.3rem;font-weight:700;color:#0f172a;}}
.section{margin-bottom:24px;h2{font-size:1rem;font-weight:700;color:#1e293b;margin-bottom:12px;}}
.progress-bar{background:#f1f5f9;border-radius:99px;height:8px;width:100%;max-width:120px;display:inline-block;margin-right:8px;vertical-align:middle;}
.progress-fill{background:linear-gradient(90deg,#0284c7,#38bdf8);height:100%;border-radius:99px;}
.page-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:24px;}
.page-header h1{margin:0;font-size:1.6rem;font-weight:700;}.subtitle{color:#64748b;}
.table-card{background:#fff;border-radius:12px;overflow:auto;border:1px solid #e2e8f0;}
table{width:100%;border-collapse:collapse;}
thead tr{background:#f8fafc;}th,td{padding:12px 16px;text-align:left;font-size:.875rem;border-bottom:1px solid #f1f5f9;}
th{font-weight:600;color:#374151;}td{color:#475569;}
.btn{padding:9px 18px;border-radius:8px;border:none;cursor:pointer;font-size:.875rem;font-weight:600;}
.btn-primary{background:linear-gradient(135deg,#0284c7,#38bdf8);color:#fff;}
.btn-secondary{background:#f1f5f9;color:#374151;}
.loading-state{text-align:center;padding:40px;color:#64748b;}
  `],
})
export class ReportsComponent implements OnInit {
  private api = inject(ApiService);
  report = signal<any>(null); loading = signal(false);
  start = ""; end = "";

  ngOnInit(): void {
    const now = new Date();
    const first = new Date(now.getFullYear(), now.getMonth(), 1);
    this.start = first.toISOString().split("T")[0];
    this.end   = now.toISOString().split("T")[0];
    this.load();
  }
  load(): void {
    this.loading.set(true);
    this.api.getFuelReport({ start: this.start, end: this.end }).subscribe({ next: r => { this.report.set(r); this.loading.set(false); }, error: () => this.loading.set(false) });
  }
  exportCsv(): void {
    const r = this.report();
    if (!r) return;
    const rows = [["Véhicule","Opérations","Volume (L)","Coût (FCFA)"]];
    r.byVehicle.forEach((v: any) => rows.push([`${v.vehicle?.plate} – ${v.vehicle?.brand}`, v.count, v.qty.toFixed(1), v.cost.toFixed(0)]));
    const csv = rows.map(r => r.join(";")).join("\n");
    const a = document.createElement("a");
    a.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    a.download = `rapport-carburant-${this.start}-${this.end}.csv`;
    a.click();
  }
}
