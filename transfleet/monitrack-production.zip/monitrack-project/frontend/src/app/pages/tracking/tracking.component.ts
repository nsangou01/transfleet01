import { Component, inject, signal, OnInit, OnDestroy } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ApiService } from "../../core/services/api.service";
import { TrackingPoint, Vehicle } from "../../core/models";

interface VehicleStatus { vehicle: Vehicle; lastPosition: TrackingPoint | null }

@Component({
  selector: "app-tracking", standalone: true, imports: [CommonModule],
  template: `
<div class="page">
  <div class="page-header">
    <div><h1>📍 Suivi GPS</h1><p class="subtitle">Positions en temps réel (actualisation toutes les 30s)</p></div>
    <div class="header-actions">
      <span class="badge badge-scheduled">{{ lastUpdate() }}</span>
      <button class="btn btn-secondary" (click)="load()">↻ Actualiser</button>
    </div>
  </div>
  @if (loading()) { <div class="loading-state">Chargement…</div> }
  <div class="tracking-grid">
    @for (item of data(); track item.vehicle.id) {
      <div class="tracking-card" [class]="'status-' + item.vehicle.status">
        <div class="tc-header">
          <div class="tc-plate">{{ item.vehicle.plate }}</div>
          <span class="badge" [class]="'badge-' + item.vehicle.status">{{ statusLabel(item.vehicle.status) }}</span>
        </div>
        <div class="tc-vehicle">{{ item.vehicle.brand }} {{ item.vehicle.model }}</div>
        @if (item.lastPosition) {
          <div class="tc-info">
            <div class="tc-row"><span>Latitude</span><strong>{{ item.lastPosition.latitude }}</strong></div>
            <div class="tc-row"><span>Longitude</span><strong>{{ item.lastPosition.longitude }}</strong></div>
            <div class="tc-row"><span>Vitesse</span><strong>{{ item.lastPosition.speed ?? 0 }} km/h</strong></div>
            <div class="tc-row"><span>Moteur</span><strong>{{ item.lastPosition.engine_status === "on" ? "✅ En marche" : "⏹️ Arrêté" }}</strong></div>
            <div class="tc-row"><span>Kilométrage</span><strong>{{ (item.lastPosition.mileage ?? 0).toLocaleString() }} km</strong></div>
            <div class="tc-row"><span>Dernière mise à jour</span><strong>{{ item.lastPosition.recorded_at | date:"dd/MM HH:mm:ss" }}</strong></div>
          </div>
          <a [href]="mapUrl(item.lastPosition)" target="_blank" class="btn btn-secondary btn-sm">🗺️ Voir sur Google Maps</a>
        } @else {
          <div class="tc-no-data">Aucune donnée GPS disponible</div>
        }
      </div>
    }
  </div>
</div>`,
  styles: [`
.tracking-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;margin-top:20px}
.tracking-card{background:#fff;border-radius:12px;padding:18px;border:1px solid #e2e8f0;box-shadow:0 1px 3px rgba(0,0,0,.05);}
.tracking-card.status-in_use{border-left:3px solid #22c55e;}
.tracking-card.status-available{border-left:3px solid #94a3b8;}
.tracking-card.status-maintenance{border-left:3px solid #f59e0b;}
.tc-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;}
.tc-plate{font-size:1rem;font-weight:700;color:#0f172a;}
.tc-vehicle{font-size:.85rem;color:#64748b;margin-bottom:12px;}
.tc-info{display:flex;flex-direction:column;gap:6px;margin-bottom:12px;}
.tc-row{display:flex;justify-content:space-between;font-size:.82rem;span{color:#64748b;}strong{color:#1e293b;}}
.tc-no-data{text-align:center;color:#94a3b8;padding:20px;font-size:.85rem;}
.btn-sm{padding:6px 12px;font-size:.8rem;display:inline-block;text-decoration:none;border-radius:7px;border:1px solid #e2e8f0;background:#f8fafc;color:#374151;cursor:pointer;&:hover{background:#e2e8f0;}}
.page-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px;}
.page-header h1{margin:0;font-size:1.6rem;font-weight:700;}
.subtitle{color:#64748b;font-size:.9rem;}
.header-actions{display:flex;gap:8px;align-items:center;}
.badge{padding:3px 10px;border-radius:99px;font-size:.75rem;font-weight:600;}
.badge-available{background:#dcfce7;color:#15803d;}
.badge-in_use{background:#dbeafe;color:#1d4ed8;}
.badge-maintenance{background:#fef9c3;color:#854d0e;}
.badge-out_of_service{background:#fee2e2;color:#dc2626;}
.badge-scheduled{background:#f1f5f9;color:#475569;}
.btn{padding:9px 18px;border-radius:8px;border:none;cursor:pointer;font-size:.875rem;font-weight:600;}
.btn-secondary{background:#f1f5f9;color:#374151;}
.loading-state{text-align:center;padding:40px;color:#64748b;}
  `],
})
export class TrackingComponent implements OnInit, OnDestroy {
  private api = inject(ApiService);
  data = signal<VehicleStatus[]>([]);
  loading = signal(false);
  lastUpdate = signal("—");
  private timer: any;

  ngOnInit() { this.load(); this.timer = setInterval(() => this.load(), 30_000); }
  ngOnDestroy() { clearInterval(this.timer); }
  load(): void {
    this.loading.set(true);
    this.api.getTracking().subscribe({ next: r => { this.data.set(r); this.lastUpdate.set("Màj : " + new Date().toLocaleTimeString("fr-FR")); this.loading.set(false); }, error: () => this.loading.set(false) });
  }
  mapUrl(p: TrackingPoint): string { return `https://www.google.com/maps?q=${p.latitude},${p.longitude}`; }
  statusLabel(s: string): string { return ({available:"Disponible",in_use:"En route",maintenance:"Maintenance",out_of_service:"Hors service"})[s as keyof object] ?? s; }
}
