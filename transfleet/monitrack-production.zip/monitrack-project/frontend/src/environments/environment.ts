export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/api',
  appName: 'MONITRACK',
  version: '1.0.0',
};
