export const environment = {
  production: true,
  apiUrl: '/api',
  appName: 'MONITRACK',
  version: '1.0.0',
};
